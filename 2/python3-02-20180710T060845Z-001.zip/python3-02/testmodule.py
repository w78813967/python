import mymodule
mymodule.say_hello("Jia yi")
somone = mymodule.person1['age']

print(somone)