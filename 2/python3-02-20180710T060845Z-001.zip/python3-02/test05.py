class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

person01 = Person("John", 36)

print(person01.name)
print(person01.age)