def my_function(country = "Norway"):
    print("I am from " + country)

my_function("Taiwan")
my_function("India")
my_function()
