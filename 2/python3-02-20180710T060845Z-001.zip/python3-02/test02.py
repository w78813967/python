def my_function(name):
    print('hello! ' + name)

my_function("Apple")
my_function("Linus")